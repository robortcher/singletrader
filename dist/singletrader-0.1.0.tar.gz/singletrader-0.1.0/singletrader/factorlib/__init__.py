"""
因子测试工具包
"""
from .factortesting import FactorEvaluation,summary_plot

